// ExactSolver.java
import java.util.*;

class ExactSolver {
    private int n;
    private int[][] dist;
    private int bestRadius;
    private List<Integer> bestCenters;
    
    public ExactSolver(int n, int[][] dist) {
        this.n = n;
        this.dist = dist;
        this.bestRadius = Integer.MAX_VALUE;
        this.bestCenters = new ArrayList<>();
    }
    
    public int solve(int k) {
        bestRadius = Integer.MAX_VALUE;
        bestCenters.clear();
        
        List<Integer> centers = new ArrayList<>();
        findOptimalCenters(1, k, centers);
        
        return bestRadius;
    }
    
    private void findOptimalCenters(int start, int remaining, List<Integer> centers) {
        if (remaining == 0) {
            int radius = calculateRadius(centers);
            if (radius < bestRadius) {
                bestRadius = radius;
                bestCenters = new ArrayList<>(centers);
            }
            return;
        }
        
        // Poda: se não há vértices suficientes restantes
        if (n - start + 1 < remaining) {
            return;
        }
        
        // Poda adicional: se o raio atual já é maior que o melhor encontrado
        if (!centers.isEmpty()) {
            int currentRadius = calculateRadius(centers);
            if (currentRadius >= bestRadius) {
                return;
            }
        }
        
        for (int i = start; i <= n; i++) {
            centers.add(i);
            findOptimalCenters(i + 1, remaining - 1, centers);
            centers.remove(centers.size() - 1);
            
            // Se já encontramos uma solução muito boa, podemos parar
            if (bestRadius == 0) break;
        }
    }
    
    private int calculateRadius(List<Integer> centers) {
        int maxDist = 0;
        
        for (int v = 1; v <= n; v++) {
            int minDistToCenter = Integer.MAX_VALUE;
            
            for (int center : centers) {
                minDistToCenter = Math.min(minDistToCenter, dist[v][center]);
            }
            
            maxDist = Math.max(maxDist, minDistToCenter);
        }
        
        return maxDist;
    }
}
