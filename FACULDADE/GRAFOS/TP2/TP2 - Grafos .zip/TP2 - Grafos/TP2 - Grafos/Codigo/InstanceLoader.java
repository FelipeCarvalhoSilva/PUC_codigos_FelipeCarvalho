// InstanceLoader.java
import java.io.*;
import java.util.*;

class InstanceLoader {
    private int n; // número de vértices
    private int[][] dist; // matriz de distâncias
    
    public InstanceLoader(String filename) throws IOException {
        loadInstance(filename);
    }
    
    private void loadInstance(String filename) throws IOException {
        //C:\\Users\\Felipe\\Desktop\\TP2 - Grafos\\TP2 - Grafos\\Codigo\\files\\
        BufferedReader br = new BufferedReader(new FileReader("files/" + filename));
        
        String[] header = br.readLine().trim().split("\\s+");
        n = Integer.parseInt(header[0]);
        int m = Integer.parseInt(header[1]);
        // O terceiro valor (header[2]) pode ser ignorado
        
        // Inicializar matriz de distâncias com infinito
        dist = new int[n + 1][n + 1];
        for (int i = 0; i <= n; i++) {
            Arrays.fill(dist[i], Integer.MAX_VALUE);
            if (i > 0) dist[i][i] = 0;
        }
        
        // Ler as arestas
        for (int i = 0; i < m; i++) {
            String[] parts = br.readLine().trim().split("\\s+");
            int u = Integer.parseInt(parts[0]);
            int v = Integer.parseInt(parts[1]);
            int cost = Integer.parseInt(parts[2]);
            
            dist[u][v] = cost;
            dist[v][u] = cost; // grafo não direcionado
        }
        
        br.close();
        
        // Aplicar Floyd-Warshall para calcular todas as distâncias
        floydWarshall();
    }
    
    private void floydWarshall() {
        for (int k = 1; k <= n; k++) {
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                    if (dist[i][k] != Integer.MAX_VALUE && 
                        dist[k][j] != Integer.MAX_VALUE &&
                        dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                    }
                }
            }
        }
    }
    
    public int getN() { return n; }
    public int getDistance(int u, int v) { return dist[u][v]; }
    public int[][] getDistanceMatrix() { return dist; }
}