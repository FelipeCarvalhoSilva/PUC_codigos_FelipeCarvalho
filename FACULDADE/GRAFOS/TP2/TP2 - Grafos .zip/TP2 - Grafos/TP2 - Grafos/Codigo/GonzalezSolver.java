// GonzalezSolver.java
import java.util.*;

class GonzalezSolver {
    private int n;
    private int[][] dist;
    
    public GonzalezSolver(int n, int[][] dist) {
        this.n = n;
        this.dist = dist;
    }
    
    public int solve(int k) {
        List<Integer> centers = new ArrayList<>();
        
        // Escolher o primeiro centro arbitrariamente (vértice 1)
        centers.add(1);
        
        // Escolher os k-1 centros restantes
        for (int i = 1; i < k; i++) {
            int farthestVertex = findFarthestVertex(centers);
            centers.add(farthestVertex);
        }
        
        return calculateRadius(centers);
    }
    
    private int findFarthestVertex(List<Integer> centers) {
        int farthestVertex = -1;
        int maxMinDist = -1;
        
        for (int v = 1; v <= n; v++) {
            if (centers.contains(v)) continue;
            
            int minDistToCenter = Integer.MAX_VALUE;
            for (int center : centers) {
                minDistToCenter = Math.min(minDistToCenter, dist[v][center]);
            }
            
            if (minDistToCenter > maxMinDist) {
                maxMinDist = minDistToCenter;
                farthestVertex = v;
            }
        }
        
        return farthestVertex;
    }
    
    private int calculateRadius(List<Integer> centers) {
        int maxDist = 0;
        
        for (int v = 1; v <= n; v++) {
            int minDistToCenter = Integer.MAX_VALUE;
            
            for (int center : centers) {
                minDistToCenter = Math.min(minDistToCenter, dist[v][center]);
            }
            
            maxDist = Math.max(maxDist, minDistToCenter);
        }
        
        return maxDist;
    }
}
