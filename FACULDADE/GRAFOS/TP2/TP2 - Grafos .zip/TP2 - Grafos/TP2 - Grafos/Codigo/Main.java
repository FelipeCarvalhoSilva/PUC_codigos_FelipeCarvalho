import java.io.IOException;

public class Main {
    // Tabela com os valores de k para cada instância (conforme Tabela 1 do enunciado)
    private static final int[] K_VALUES = {
        5, 10, 10, 20, 33,    // pmed1-5
        5, 10, 20, 40, 67,    // pmed6-10
        5, 10, 30, 60, 100,   // pmed11-15
        5, 10, 40, 80, 133,   // pmed16-20
        5, 10, 50, 100, 167,  // pmed21-25
        5, 10, 60, 120, 200,  // pmed26-30
        5, 10, 70, 140, 5,    // pmed31-35 (pmed35 tem k=5 conforme tabela)
        10, 80, 5, 10, 90     // pmed36-40
    };
    
    public static void main(String[] args) {
        System.out.println("=== Solução do Problema dos K-Centros ===\n");
        
        for (int i = 1; i <= 40; i++) {
            String filename = "pmed" + i + ".txt";
            int k = K_VALUES[i - 1];
            
            try {
                System.out.println("Instância: " + filename);
                System.out.println("k = " + k);
                
                // Carregar instância
                InstanceLoader loader = new InstanceLoader(filename);
                int n = loader.getN();
                int[][] dist = loader.getDistanceMatrix();
                
                System.out.println("n = " + n + ", k = " + k); // Debug
                
                // Executar algoritmo exato (sem limite)
                ExactSolver exactSolver = new ExactSolver(n, dist);
                
                long startTime = System.nanoTime();
                int exactRadius = exactSolver.solve(k);
                long endTime = System.nanoTime();
                double exactTime = (endTime - startTime) / 1_000_000.0; // ms
                
                System.out.println("Algoritmo Exato:");
                System.out.println("  Raio: " + exactRadius);
                System.out.println("  Tempo: " + String.format("%.2f", exactTime) + " ms");
                
                // Executar algoritmo aproximado (Gonzalez)
                GonzalezSolver gonzalezSolver = new GonzalezSolver(n, dist);
                
                startTime = System.nanoTime();
                int gonzalezRadius = gonzalezSolver.solve(k);
                endTime = System.nanoTime();
                double gonzalezTime = (endTime - startTime) / 1_000_000.0; // ms
                
                System.out.println("Algoritmo Aproximado (Gonzalez):");
                System.out.println("  Raio: " + gonzalezRadius);
                System.out.println("  Tempo: " + String.format("%.2f", gonzalezTime) + " ms");
                
                System.out.println();
                
            } catch (IOException e) {
                System.err.println("Erro ao carregar " + filename + ": " + e.getMessage());
                System.out.println();
            }
        }
    }
}
